﻿namespace SoftUni.Blog.Models
{
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using System.Collections.Generic;

    public class User : IdentityUser
    {
        //private ICollection<Post> posts; 

        //public User()
        //{
        //    this.Posts = new HashSet<Post>();
        //}

        //public virtual ICollection<Post> Posts {
        //    get { return this.posts; }

        //    set { this.posts = value; }
        //}

        public string Fullname { get; set; }

        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<User> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }
}
